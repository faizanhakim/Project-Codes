#include <iostream>
#include <fstream>
#include "waiter.cpp"


using namespace std;

int main(){
    system("cls");

    ifstream file_read("waiter.dat",ios::in | ios::binary);

    waiter obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        obj.display();
        file_read.read((char*)&obj, sizeof(obj));
    }

    file_read.close();
    
}