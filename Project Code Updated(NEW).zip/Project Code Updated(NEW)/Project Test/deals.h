#include <iostream>
#include "Menu.h"
using namespace std;

class Deals:public Menu {
    double amount;
    double discount;
};