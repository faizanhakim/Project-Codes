#include <iostream>
#include "Menu.h"
using namespace std;

class restaurant{
    const string res_name;
    Menu m;
};