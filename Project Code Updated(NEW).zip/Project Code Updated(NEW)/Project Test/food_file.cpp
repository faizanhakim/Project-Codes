#include <iostream>
#include <fstream>
#include "food.cpp"


using namespace std;

int main(){
    system("cls");
    food f1;
    
    f1.set_foodID();
    f1.set_item_name();
    f1.set_price();

    ofstream file;
    file.open("food.dat",ios::out | ios::binary);

    file.write((char*)&f1,sizeof(f1));

    file.close();

    
}