#include <iostream>
#include <fstream>
#include "food.cpp"


using namespace std;

int main(){
    system("cls");

    ifstream file_read("food.dat", ios::in | ios::binary);

    food obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(file_read){
        obj.display();
        file_read.read((char*)&obj, sizeof(obj));
    }

    file_read.close();
    //obj.display();
    cout << "Program ended! " << endl;
  
}