#include <iostream>
#include "table.cpp"

using namespace std;

class manager:public Staff {
    char username[25];
    char pass[25];

    public:
        manager(){}
        //manager(string n,string id,double sal,string add,string phnum);
        void set_name();
        void set_userName();
        void set_password();
        void set_phNUM();
        void set_address();
        void set_ID();
        void set_salary();
        double get_salary();
        string get_ID();
        string get_name();
        string get_username();
        string get_password();
        string get_phNUM();
        string get_address();
};