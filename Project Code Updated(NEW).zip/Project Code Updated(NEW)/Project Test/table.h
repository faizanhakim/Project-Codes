#include <iostream>
#include "waiter.cpp"
#include "customer.cpp"

using namespace std;

class table{
    protected:
        char table_id[24];
        int seat_num;
        bool available;
        waiter w;
        customer c;

    public:
        int static total_tables;
        table(){};
        //table(string tableID, int s_num, bool avail);
        void set_tableID();
        string get_tableID();
        void set_seatNUM();
        int get_seatNUM();
        void set_available(bool avail);
        bool get_available();
        void assign_waiter(vector<waiter>wait);
        string get_waiterNAME();
        string get_waiterID();
        void set_customer();
        void display();
        void display_customer();
        void set_waiterName();
        void reset_waiter();
        void write_cus_file();
        string get_cus_name();
};