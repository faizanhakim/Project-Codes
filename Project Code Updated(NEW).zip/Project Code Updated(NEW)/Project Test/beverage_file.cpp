#include <iostream>
#include <fstream>
#include "beverage.cpp"


using namespace std;

int main(){
    system("cls");

    beverages b1;
    b1.set_beverageID();
    b1.set_item_name();
    b1.set_price();

    ofstream file;
    file.open("beverages.dat",ios::out | ios::binary);

    file.write((char*)&b1,sizeof(b1));

    file.close(); 
}