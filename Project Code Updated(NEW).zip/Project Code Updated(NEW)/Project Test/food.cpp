#include<iostream>
#include"food.h"

using namespace std;

void food::set_foodID(){
    cout << "Enter food ID: ";
    cin >> food_id;
}

string food ::get_foodID(){
    return food_id; 
}

void food::set_item_name(){
    cout << "Enter item name:";
    cin >> food_name;  
}
void food ::set_price(){
    cout << "Enter item price: ";
    cin >> price;
}   

string food ::get_item_name(){
    return food_name;
}

double food ::get_price(){
    return price;
}

void food ::set_quantity(){
    cout << "Enter quantity: ";
    cin >> quantity; 
}

int food ::get_quantity(){
    return quantity;
}

void food::display(){
    cout << "Food Id: " << food_id << endl;
    cout << "Food Name: " << food_name << endl;
    cout << "Food Price: " << price << endl;
    
}
