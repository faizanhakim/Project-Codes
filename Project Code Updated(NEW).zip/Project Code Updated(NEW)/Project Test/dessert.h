#include<iostream>

using namespace std;

class dessert{
    char dessert_id[24];
    char dessert_name[24];
    double price;
    int quantity;
    

    public:
        //dessert(string id, string name, double price1):dessert_id(id),dessert_name(name),price(price1){}
        dessert(){}
        void set_id();
        void set_item_name();
        void set_price();
        void set_quantity();
        int get_quantity();
        string get_item_name();
        string get_dessertID();
        double get_price();
        //dessert(string n, double p, char t, string id):Menu(n,p,t),dessert_id(id){}
        
        void display();
};