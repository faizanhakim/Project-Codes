#include<iostream>
#include "order.h"
#include <ctime>
#include <fstream>
#include<string>

using namespace std;

order::order(){
    cout<<"READY TO TAKE ORDER"<<endl;
    total_bill=0;
}

order::~order(){
    delete items_id;
}

void order ::display_bill()
{
    display();
    
    for(int i=0;i<order_f.size();i++)
    {
        cout << "Item: " << order_f[i].get_item_name();
        cout << "\tQuantity: " << order_f[i].get_quantity();
        cout << "\tPrice: " << order_f[i].get_price();
        cout << "\tTotal: " << order_f[i].get_price() * order_f[i].get_quantity();
        cout << endl << endl;
    }

    for(int i=0;i<order_b.size();i++)
    {
        cout << "Item: " << order_b[i].get_item_name();
        cout << "\tQuantity: " << order_b[i].get_quantity();
        cout << "\tPrice: " << order_b[i].get_price();
        cout << "\tTotal: " << order_b[i].get_price() * order_b[i].get_quantity();
        cout << endl << endl;
    }
    
    for(int i=0;i<order_d.size();i++)
    {
        cout << "Item: " << order_d[i].get_item_name();
        cout << "\tQuantity: " << order_d[i].get_quantity();
        cout << "\tPrice: " << order_d[i].get_price();
        cout << "\tTotal: " << order_d[i].get_price() * order_d[i].get_quantity();
        cout << endl << endl;
    }

    cout << endl << "Total Bill: " << total_bill;
}

void order ::bill(){

    for(int i=0;i<order_f.size();i++)
    {
        total_bill += order_f[i].get_price() * order_f[i].get_quantity();
    }

    for(int i=0;i<order_b.size();i++)
    {
        total_bill += order_b[i].get_price() * order_b[i].get_quantity();
    }
    
    for(int i=0;i<order_d.size();i++)
    {
        total_bill += order_d[i].get_price() * order_d[i].get_quantity();
    }
}

void order::set_order(class Menu menu,int n){
    char type;

    total_items = n;
    items_id = new string[n]; 

    for(int i=0;i<n;i++){
        cout<<"Enter Type of Item "<<i+1<<" (F/B/D): ";
        cin>>type;
        type = toupper(type);
        switch(type){
            case 'F':
            {
                cout<<"Enter Food ID: "<<flush;
                cin>>items_id[i];

                while(!menu.validate_food(items_id[i])){
                    cout<<endl;
                    cout<<"Item does not exits!"<<endl<<"Enter correct ID: ";
                    cin>>items_id[i];
                }

                order_f.push_back(menu.find_food(items_id[i]));
                order_f[order_f.size()-1].set_quantity();
                break;
            }
            case 'B':
            {
                cout << "Enter Beverage ID: "<<flush;
                cin >> items_id[i];

                while(!menu.validate_beverage(items_id[i])){
                    cout<<endl;
                    cout<<"Item does not exits!"<<endl<<"Enter correct ID: ";
                    cin>>items_id[i];
                }
                
                order_b.push_back(menu.find_beverage(items_id[i]));
                order_b[order_b.size()-1].set_quantity();
                break;
            }
            case 'D':
            {
                cout<<"Enter Dessert ID: "<<flush;
                cin>>items_id[i];

                while(!menu.validate_dessert(items_id[i])){
                    cout<<endl;
                    cout<<"Item does not exits!"<<endl<<"Enter correct ID: ";
                    cin>>items_id[i];
                }

                order_d.push_back(menu.find_dessert(items_id[i]));
                order_d[order_d.size()-1].set_quantity();
                break;
            }
        }

        cout<<endl;
    }
}



void order::set_customer(class customer cus){
    customer_details = cus;
}

bool order::set_table(vector <table> tab){
    string temp_tableID;
    bool found = false; bool found1 = false;
    cout << "Enter Table ID: "; fflush(stdin); getline(cin,temp_tableID);
    
    for(int k=0; k<tab.size();k++)
    {
        if(temp_tableID==tab[k].get_tableID())
        {   
            found1=true;
            if (tab[k].get_available() == false){
                table_details = tab[k];
                waiter_name = table_details.get_waiterNAME();
                waiter_id = table_details.get_waiterID();
                found = true;
                break;
            }
            else{
                cout << "Table is not booked!" << endl;
                found = false;
                break;
            }
        }
        else{
            found1 = false;
            continue;
        }
    }

    if(found1==false){
        cout<<"Table is not Avaialble"<<endl;
    }
    return found; 
}

void order::display(){
    cout << "Table ID: " << table_details.get_tableID() << endl;
    cout << "Waiter Name: " << table_details.get_waiterNAME() << endl;
    cout << "Total number of items: " << total_items << endl << endl;

    cout << "Customer Details: " << endl << endl;
    table_details.display_customer(); 
    cout << endl;

    for (int i=0;i<order_f.size();i++){
        order_f[i].display();
        cout << "Quantity: " << order_f[i].get_quantity() << endl;
        }
    cout<<endl;

    for (int i=0;i<order_b.size();i++){
        order_b[i].display();
        cout << "Quantity: " << order_b[i].get_quantity() << endl;
    }
    cout<<endl;

    for (int i=0;i<order_d.size();i++){
        order_d[i].display();
        cout << "Quantity: " << order_d[i].get_quantity() << endl;
    }
    cout<<endl;

}


void order::write_bill_file(){
    time_t now = time(0);
    tm *ltm = localtime(&now); 
    int var = 1900 + ltm->tm_year;
    int var1 = 1 + ltm->tm_mon;
    int var2 = ltm->tm_mday;
    string title;
    string DATE;
    string Day = to_string(var2);
    string Month = to_string(var1);
    string Year = to_string(var);
    DATE = Day + Month + Year;
    
    title = "bill" + DATE + ".txt";

    ofstream file;
    file.open(title,ios::out|ios::app); 

    file << "Table ID: " << table_details.get_tableID() << endl;
    file << "Waiter Name: " << table_details.get_waiterNAME() << endl;
    file << "Total number of items: " << total_items << endl << endl;

    file << "Customer Details: " << endl << endl;
    file << table_details.get_cus_name();
    file << endl;


    for(int i=0;i<order_f.size();i++)
    {
        file << "Item: " << order_f[i].get_item_name();
        file << "\tQuantity: " << order_f[i].get_quantity();
        file << "\tPrice: " << order_f[i].get_price();
        file << "\tTotal: " << order_f[i].get_price() * order_f[i].get_quantity();
        file << endl << endl;
    }

    for(int i=0;i<order_b.size();i++)
    {
        file << "Item: " << order_b[i].get_item_name();
        file << "\tQuantity: " << order_b[i].get_quantity();
        file << "\tPrice: " << order_b[i].get_price();
        file << "\tTotal: " << order_b[i].get_price() * order_b[i].get_quantity();
        file << endl << endl;
    }
    
    for(int i=0;i<order_d.size();i++)
    {
        file << "Item: " << order_d[i].get_item_name();
        file << "\tQuantity: " << order_d[i].get_quantity();
        file << "\tPrice: " << order_d[i].get_price();
        file << "\tTotal: " << order_d[i].get_price() * order_d[i].get_quantity();
        file << endl << endl;
    }

    file << endl << "Total Bill: " << total_bill;

    file <<endl<<"-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*--*-*"<<endl<<endl;

    file.close();
}