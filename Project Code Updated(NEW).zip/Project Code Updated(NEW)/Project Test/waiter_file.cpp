#include <iostream>
#include <fstream>
#include "waiter.cpp"


using namespace std;

int main(){
    system("cls");

    ofstream file("waiter.dat",ios::out | ios::binary);
    waiter w1;

    w1.set_ID();
    w1.set_name();
    w1.set_phNUM();
    w1.set_salary();
    w1.set_address();

    file.write((char*)&w1,sizeof(w1));

    file.close();
    
}