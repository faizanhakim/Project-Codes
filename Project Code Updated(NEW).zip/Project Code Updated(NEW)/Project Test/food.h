#include<iostream>
using namespace std;

class food{
    public:
    char food_id[25];
    char food_name[35];
    double price;
    int quantity;


    public:
        //food(string id, string name, double price1):food_id(id),food_name(name),price(price1){}
        food(){};
        void set_foodID();
        void set_item_name();
        void set_price();
        void set_quantity();
        string get_item_name();
        double get_price();
        string get_foodID();
        //food(string n, double p, char t, string id):Menu(n,p,t),food_id(id){}
        int get_quantity();
        void display();
};