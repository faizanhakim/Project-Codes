#include <iostream>
#include "customer.h"

using namespace std;

//int customer::c_id=0;

/*customer::customer(string c_n,string c_d,string ph_n,string num,bool r){
    c_name = c_n;
    c_address = c_d;
    ph_num = ph_n;
    reg_cus = r;
}*/

void customer::set_c_name(){
    cout<<"Enter Customer's Name: ";
    cin>>c_name;
    
}

void customer::set_address(){
    cout<<"Enter Customer's Address: ";
    cin>>c_address;
}

void customer::set_ph_num(){
    cout<<"Enter Customer's Phone number: ";
    cin>>ph_num;
}

string customer::get_cName(){
    fflush(stdout);
    return c_name;
}

/*int customer::get_cID(){
    return c_id;
}*/

string customer::get_address(){
    return c_address;
}

string customer::get_phNUM(){
    return ph_num;
}

void customer::display(){
    cout<<"Customer: "<<endl;
    cout<<"Name: "<<c_name<<endl;
    //cout<<"ID: "<<c_id<<endl;
}