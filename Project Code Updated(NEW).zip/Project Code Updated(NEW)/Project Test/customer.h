#include <iostream>

using namespace std;

class customer {
    protected:
        char c_name[35];
        char c_address[100];
        char ph_num[34];
    public:
      
        //int static c_id;
        customer(){};
        //customer(string c_n,string c_d,string ph_n,string num,bool r);
        void set_c_name();
        void set_c_id();
        void set_address();
        void set_ph_num();
        
        void change_regCUS(int a);

        string get_cName();
        string get_address();
        string get_phNUM();

        void display();
        
};