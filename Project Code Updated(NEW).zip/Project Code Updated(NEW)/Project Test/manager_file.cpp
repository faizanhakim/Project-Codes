#include<iostream>
#include<fstream>
#include"manager.cpp"
using namespace std;

int main(){
    system("CLS");
    manager man;

    man.set_name();
    man.set_phNUM();
    man.set_address();
    man.set_ID();
    man.set_salary();

    man.set_userName();
    man.set_password();

    ofstream file;
    file.open("Manager.dat",ios::binary);
    file.write((char*)&man,sizeof(man));
    file.close();
}