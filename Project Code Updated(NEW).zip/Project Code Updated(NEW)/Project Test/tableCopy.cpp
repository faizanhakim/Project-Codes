#include <iostream>
#include <fstream>
#include "table.cpp"
//#include "waiter.cpp"

using namespace std;

int main(){
    system("CLS");
    
    ifstream file_read("table.dat",ios::in | ios::binary);

    table obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        obj.display();
        file_read.read((char*)&obj, sizeof(obj));
    }

    
}