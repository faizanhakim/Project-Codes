#include<iostream>
using namespace std;

class beverages{
    char beverage_id[25];
    char beverage_name[25];
    double price;
    int quantity;
    
    public:
        //beverages(string id, string name, double price1):beverage_id(id),beverage_name(name),price(price1){}
        beverages(){};

        void set_beverageID();
        void set_item_name();
        void set_price();
        
        string get_beverageID();
        string get_item_name();
        double get_price();
        void set_quantity();
        int get_quantity();
        void display();
        
    //beverages(string n, double p, char t, string id):Menu(n,p,t),beverage_id(id){}
};