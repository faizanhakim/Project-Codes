#include <iostream>
using namespace std;

class Staff{
    protected:
        char staff_id[25];
        char staff_name[25];
        double salary;
        char address[100];
        char ph_num[25];
        //string w;
    public:
        Staff(){}
        virtual void set_name() = 0;
        virtual string get_name() = 0;
        virtual void set_ID() = 0;
        virtual string get_ID() = 0;
        virtual void set_salary() = 0;
        virtual double get_salary() = 0;
        virtual void set_address() = 0;
        virtual string get_address() = 0;
        virtual void set_phNUM() = 0;
        virtual string get_phNUM() = 0;
};