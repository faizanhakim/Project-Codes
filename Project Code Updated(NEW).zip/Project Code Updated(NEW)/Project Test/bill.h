#include <iostream>

#include "order.h"
#include "customer.h"

class bill:public order,public customer{
    double total;
    double discount;
    //int bill_num;
};