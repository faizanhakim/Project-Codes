#include <iostream>
#include "staff.h"

using namespace std;
class waiter:public Staff {

    public:
        waiter(){}
        //static int waiter_num;
        //waiter(string n,string id,double sal,string add,string phnum);
        void set_name();
        string get_name();
        void set_ID();
        string get_ID();
        void set_salary();
        double get_salary();
        void set_address();
        string get_address();
        void set_phNUM();
        string get_phNUM();

        void display();
        void reset_name();
};