#include<iostream>
#include"beverages.h"

using namespace std;

void beverages::set_beverageID(){

    cout<<"Enter Beverage ID: ";
    cin>>beverage_id;
}

string beverages::get_beverageID(){
    return beverage_id;
}

void beverages::set_item_name(){
    cout << "Enter item name:";
    cin >> beverage_name;  
}
void beverages::set_price(){
    cout << "Enter item price: ";
    cin >> price;
}   

string beverages::get_item_name(){
    return beverage_name;
}

double beverages::get_price(){
    return price;
}

void beverages ::set_quantity(){
    cout << "Enter Quantity: ";
    cin >> quantity;
}

int beverages::get_quantity(){
    return quantity;
}

void beverages::display(){
    cout << "beverage ID: " << beverage_id << endl;
    cout << "beverage Name: " << beverage_name << endl;
    cout << "beverage Price: " << price << endl;
}