#include <iostream>
#include"Menu.h"
#include<string.h>
#include <vector>

using namespace std;

int Menu::f_num = 0;
int Menu::d_num = 0;
int Menu::b_num = 0;

void Menu::display_food(){
    for(int i=0;i<f.size();i++){
        cout<<f[i].get_item_name()<<endl;
        cout<<f[i].get_price()<<endl;
        cout<<f[i].get_foodID()<<endl;

        cout<<endl;
    }
}

void Menu::display_beverage(){
    for(int i=0;i<b.size();i++){
        cout<<b[i].get_item_name()<<endl;
        cout<<b[i].get_price()<<endl;
        cout<<b[i].get_beverageID()<<endl;

        cout<<endl;
    }
}

void Menu::display_dessert(){
    for(int i=0;i<d.size();i++){
        cout<<d[i].get_item_name()<<endl;
        cout<<d[i].get_price()<<endl;
        cout<<d[i].get_dessertID()<<endl;

        cout<<endl;
    }
}

food Menu::find_food(string id){
    bool found = false;
    for(int i=0;i<f.size();i++){
        if(f[i].get_foodID()==id){
            found =  true;
            return f[i];
        }
        else{
            found = false;
            continue;
        }
    }

    if(found ==  false)
        cout<<"ITEM NOT FOUND"<<endl;
}

beverages Menu::find_beverage(string id){
    bool found = false;
    for(int i=0;i<b.size();i++){
        if(b[i].get_beverageID()==id){
            found =  true;
            return b[i];
            break;
        }
        else{
            found = false;
            continue;
        }
    }

    if(found ==  false)
        cout<<"ITEM NOT FOUND"<<endl;
}

dessert Menu::find_dessert(string id){
    bool found = false;
    for(int i=0;i<d.size();i++){
        if(d[i].get_dessertID()==id){
            found =  true;
            return d[i];
            break;
        }
            else{
            found = false;
            continue;
        }
        }

    if(found ==  false){
        cout<<"ITEM NOT FOUND"<<endl;
    }
}


void Menu::assign_food(vector<food>fd){

    for(int i=0;i<fd.size();i++){
        f.push_back(fd[i]);
    }
}

void Menu::assign_dessert(vector<dessert>dess){

    for(int i=0;i<dess.size();i++){
        d.push_back(dess[i]);
    }
}

void Menu::assign_beverages(vector<beverages>bev){

    for(int i=0;i<bev.size();i++){
        b.push_back(bev[i]);
    }
}

int Menu::get_foodSize(){
    return f.size();
}
int Menu::get_dessertSize(){
    return d.size();
}
int Menu::get_beverageSize(){
    return b.size();
}


bool Menu::validate_food(string food){
    bool found = false;
    for(int i=0;i<f.size();i++){
        if(f[i].get_foodID()==food){
            found = true;
            break;
        }
        else{
            found = false;
            continue;
        }
    }

return found;
}


bool Menu::validate_dessert(string dessert){
    bool found = false;
    for(int i=0;i<d.size();i++){
        if(d[i].get_dessertID()==dessert){
            found = true;
            break;
        }
        else{
            found = false;
            continue;
        }
    }

return found;
}


bool Menu::validate_beverage(string beverage){
    bool found = false;
    for(int i=0;i<b.size();i++){
        if(b[i].get_beverageID()==beverage){
            found = true;
            break;
        }
        else{
            found = false;
            continue;
        }
    }

return found;
}