#include <iostream>
#include "Menu.cpp"
#include "manager.cpp"
#include <vector>

using  namespace std;

class order{    
    double total_bill;
    int total_items;
    vector<food>order_f;
    vector<beverages>order_b;
    vector<dessert>order_d;
    string *items_id;
    string waiter_name, waiter_id;
    class customer customer_details;
    class table table_details;

    public:
        order();
        ~order();
        void set_customer(class customer cus);
        bool set_table(vector <table> tab);
        void display();
        void set_order(class Menu menu,int n);
        void bill();
        void display_bill();
        void write_bill_file();
};      