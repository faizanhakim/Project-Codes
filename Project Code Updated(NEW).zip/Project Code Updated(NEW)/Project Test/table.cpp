#include<vector>
#include <iostream>
#include <fstream>
#include "table.h"
#include <string.h>
#include <ctime>

using namespace std;

int table::total_tables=0;


void table::set_seatNUM(){
    cout<<"Enter Number of Seats: ";
    cin>>seat_num;
}

int table::get_seatNUM(){
    return seat_num;
}

void table::set_available(bool avail){
    available = avail;
}

bool table::get_available(){
    return available;
}

void table::set_tableID(){
    cout<<"Enter Table ID: "<<endl;
    cin>>table_id;
}

string table::get_tableID(){
    return table_id;
}

void table::set_customer(){
    cout << "Enter Customer Details: " << endl << endl;
    c.set_c_name();
    cout << endl;
    c.set_ph_num();
    cout << endl;
    c.set_address();
    cout << endl;
}

void table::display_customer(){
    cout << "Name: " << c.get_cName();
    cout << endl;
}

void table::assign_waiter(vector<waiter>wait){
    cout<<"Enter ID of the waiter: ";
    string pseudo_id;
    cin >> pseudo_id;

    int found_num;
    int found=0;

    while(true){
        for(int i=0;i<wait.size();i++){
            if(wait[i].get_ID() == pseudo_id){
                w = wait[i];
                found = 1;
                found_num = i;
                break;
            }
            else{
                found = 0;
            }
        }

        if(found==1){
            cout<<"Waiter "<<wait[found_num].get_name()<<" Assigned"<<endl;
            break;
        }
        else{
            cout << "Waiter unavailable!" << endl;
            cout << "Renter ID of the waiter: ";
            cin >> pseudo_id;
            continue;
        }
    }
}


void table::set_waiterName(){
    w.set_name();
}

string table::get_waiterNAME(){
    return w.get_name();
}

string table::get_waiterID(){
    return w.get_ID();
}

void table::display(){
    cout << "Table ID: " << table_id << endl;
    cout << "No. of Seats: " << seat_num << endl;
    if (available == true){
        cout << "Available" << endl;
    }
    else{
        cout << "Not Available" << endl;
    }

    cout << "Waiter Name: " << w.get_name() << endl;
    
}

void table::reset_waiter(){
    w.reset_name();
}

void table::write_cus_file(){
     
    time_t now = time(0);
    tm *ltm = localtime(&now); 
    int var = 1900 + ltm->tm_year;
    int var1 = 1 + ltm->tm_mon;
    int var2 = ltm->tm_mday;
    string title;
    string DATE;
    string Day = to_string(var2);
    string Month = to_string(var1);
    string Year = to_string(var);
    DATE = Day + Month + Year;
    
    title = "customer" + DATE + ".txt";

    ofstream file;
    file.open(title,ios::app); 

    file << c.get_cName()  <<  endl;
    file << c.get_address() << endl;
    file << c.get_phNUM() << endl << endl << endl;

    file.close();
}

string table::get_cus_name(){
    return c.get_cName();
}