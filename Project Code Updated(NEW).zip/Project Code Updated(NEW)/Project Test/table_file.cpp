#include <iostream>
#include <fstream>
#include "table.cpp"
//#include "waiter.cpp"

using namespace std;

int main(){
    system("CLS");
    
    table t1;
    t1.set_tableID();
    t1.set_seatNUM();
    t1.set_available(true);
    t1.set_waiterName();
    
    ofstream file("table.dat",ios::out | ios:: binary);
    file.write((char*)&t1,sizeof(t1));

    file.close();
    
}