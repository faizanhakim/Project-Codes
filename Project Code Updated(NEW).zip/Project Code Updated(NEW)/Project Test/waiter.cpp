#include<iostream>
#include <string.h>
#include"waiter.h"

using namespace std;

void waiter::set_name(){
    cout<<"Enter Waiter's Name: "<<flush;
    cin >> staff_name;
}

string waiter::get_name(){
    return staff_name;
}

void waiter::set_ID(){
    cout<<"Enter Waiter's ID: ";
    cin>>staff_id;
    //string w = staff_id;
}

string waiter::get_ID(){
    string w = "";
    for(int i=0;i<strlen(staff_id);i++){
        w+=staff_id[i];
    }

    return w;

}

void waiter::set_salary(){
    cout<<"Enter Waiter's Salary: ";
    cin>>salary;
}

double waiter::get_salary(){
    return salary;
}

void waiter::set_address(){
    cout<<"Enter Waiter's Address: ";
    cin.ignore();
    cin.getline(address,100);
}

string waiter::get_address(){
    return address;
}

void waiter::set_phNUM(){
    cout<<"Enter Waiter's Phone number: ";
    cin>>ph_num;
}

string waiter::get_phNUM(){
    return ph_num;
}

void waiter::display(){
    cout << "Waiter ID: " << staff_id << endl;
    cout << "Waiter Name: " << staff_name << endl;
    cout << "Salary: " << salary << endl;
    cout << "Address: " << address << endl;
    cout << "Phone no: " << ph_num << endl;
}

void waiter::reset_name(){
    strcpy(staff_name,"None");
}