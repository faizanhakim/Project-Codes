#include<iostream>
#include <fstream>
#include "food.cpp"
#include "beverage.cpp"
#include "dessert.cpp"
#include "table.cpp"
//#include "menu.cpp"
#include <vector>

using std::string;

vector<food>fd;
vector<beverages>bev;
vector<dessert>dess;
vector<table>tab;
vector<waiter>wait;

using namespace std;

void upload_food(vector<food>fd){
    ifstream file_read("foodCopy.txt");
    food obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        fd.push_back(obj);
        file_read.read((char*)&obj, sizeof(obj));
    }

    file_read.close();

   cout << endl << "Food items Uploaded Successfully!" << endl;
}

void prints(){
    cout << "Aahil" << endl;
}

void upload_beverages(vector<beverages>bev){
    string text;
    cout << "Enter soemthing";
//    getline(cin,text);
    ifstream file_read("beveragesCopy.txt");
    beverages obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        bev.push_back(obj);
        file_read.read((char*)&obj, sizeof(obj));
    }
    file_read.close();
    cout << "Beverages items Uploaded Successfully!" << endl;
}

void upload_dessert(vector<dessert>dess){
    ifstream file_read("dessertCopy.txt");
    dessert obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        dess.push_back(obj);
        file_read.read((char*)&obj, sizeof(obj));
    }
    file_read.close();
    cout << "Dessert items Uploaded Successfully!" << endl;
}

void upload_table(vector<table>tab){
    ifstream file_read("table.txt");
    table obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        tab.push_back(obj);
        file_read.read((char*)&obj, sizeof(obj));
    }
    file_read.close();
    cout << "size: " << tab.size() << endl << "Table information Uploaded Successfully!" << endl;
}

void upload_waiter(vector<waiter>wait){
    ifstream file_read("waiterCopy.txt");
    waiter obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        wait.push_back(obj);
        file_read.read((char*)&obj, sizeof(obj));
    }
    file_read.close();
    cout << "Waiter information Uploaded Successfully!" << endl;
}

void printMainMenu(){
    cout << "0. Enter Booking" << endl;
    cout << "1. Select Menu" << endl;
    cout << "2. Manage Staff" << endl;
    cout << "3. Manage Menu" << endl;
    cout << "4. Report" << endl; 
    cout << "6. End Day" <<endl;
}

void printTableMenu(vector<table>tab){
    for(int i=0;i<tab.size();i++){
        tab[0].display();
        cout << endl;
    }
    //cout << "ALL AVALIABLE TABLES: " << endl;
}
void printMenu(){
    cout << "ALL ITEMS ARE PRINTED" << endl;
}
void printStaff(){
    cout << "Print All Staff with designation" << endl;
}

void CheckReturn(){
    while(true){
        cout<<"Wish to go back(Y.YES N.NO): ";
        char flag;
        cin>>flag;
        if(flag=='Y'){
            system("CLS");
            break;
        }
        else{continue;}
    } 

}


int main(){
system("CLS");

//upload_food(fd);
    ifstream file_read("foodCopy.txt");
    food obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(!file_read.eof()){
        fd.push_back(obj);
        file_read.read((char*)&obj, sizeof(obj));
    }

    file_read.close();

   cout << endl << "Food items Uploaded Successfully!" << endl;
prints();
//upload_beverages(bev);
//upload_dessert(dess);
//upload_table(tab);
//upload_waiter(wait);
    ifstream file_read2("tableCopy.txt");
    table obj2;
    file_read2.read((char*)&obj2, sizeof(obj2));
    
    while(!file_read2.eof()){
        tab.push_back(obj2);
        file_read2.read((char*)&obj2, sizeof(obj2));
    }
    file_read2.close();
    cout << "size: " << tab.size() << endl << "Table information Uploaded Successfully!" << endl;



    ifstream file_read1("waiterCopy.txt");
    waiter obj1;
    file_read1.read((char*)&obj1, sizeof(obj1));
    
    while(!file_read1.eof()){
        wait.push_back(obj1);
        file_read1.read((char*)&obj1, sizeof(obj1));
    }
    file_read1.close();
    cout << "Waiter information Uploaded Successfully!" << endl;

    cout << "AAhil" << endl;

cout << "\t\t\t\t\t Begin Day(Y.YES N.NO): ";
char manage_flag;
cin >> manage_flag;

while(manage_flag=='Y'){
    printMainMenu();

    int cus_choice;
    cout<<"Enter Selection: ";  
    cin>>cus_choice;

    switch(cus_choice){

        case 0:{
            printTableMenu(tab);
            cout << "Select Table by Table's ID: ";
            string temp_id;
            cin >> temp_id;

            for(int i=0;i<tab.size();i++){
                if (temp_id == tab[i].get_tableID()){
                    if (tab[i].get_available()==true){
                        tab[i].set_available(false);
                        cout << "Table Booked Successfully!" << endl;
                        break;
                    }
                }
            }
            //Check and book Table;
            CheckReturn();
            break;
        }

        case 1:{
            printMenu();
            cout<<"Enter Number of Items: ";
            int item_num;
            cin>>item_num;

            for(int i=0;i<item_num;i++){
                cout<<"Enter dish ID: ";
                //Add all the items, based on ID, into the appropriate object using shallow or deep copy;
            }
            CheckReturn();
            break;
        }


        case 2:{
            printStaff();
            cout<<"0.Add Staff\n1.Remove Staff";
            int staff_choice;
            cin>>staff_choice;
            //Work with staff member funtions to do this
            CheckReturn();
            break;
            //Make changes in file
        }


        case 3:{
            printMenu();
            cout<<"0.Add Item\n1.Remove Item\n2.Change Item Price";
            int item_choice;
            cin>>item_choice;
            CheckReturn();
            break;
            //Made changes in file
        }

        case 4:{
            //Print all bills using objects;
            CheckReturn();
            break;
        }

    }//switch end

    if(cus_choice == 6)
    break;

}


cout<<"\nTHE DAY HAS ENDED\n"<<endl;
}//main end
