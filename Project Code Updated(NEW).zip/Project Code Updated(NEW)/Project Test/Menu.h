#include<iostream>
#include"food.cpp"
#include"beverage.cpp"
#include"dessert.cpp"
#include <vector>

using namespace std;

class Menu{
    protected: 
        vector<food>f;
        vector<dessert>d;
        vector<beverages>b;
        int static f_num, d_num, b_num;
    
    public:
        

        void display_food();
        void display_beverage();
        void display_dessert();
        void assign_food(vector<food>fd);
        void assign_dessert(vector<dessert>dess);
        void assign_beverages(vector<beverages>bev);

        int get_foodSize();
        int get_dessertSize();
        int get_beverageSize();

        food find_food(string id);
        beverages find_beverage(string id);
        dessert find_dessert(string id);

        bool validate_food(string food);
        bool validate_dessert(string dessert);
        bool validate_beverage(string beverage);
};