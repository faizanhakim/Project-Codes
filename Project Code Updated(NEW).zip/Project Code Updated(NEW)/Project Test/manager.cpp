#include<iostream>
#include "manager.h"

using namespace std;

void manager::set_ID(){
    cout << "Enter ID: ";
    cin >> staff_id;
}

void manager::set_name(){
    cout<<"Enter Manager Name: ";
    cin>>staff_name;
}

void manager::set_userName(){
    cout<<"Enter Username: ";
    cin>>username;
}
 
void manager::set_password(){
    cout<<"Enter Password: ";
    cin>>pass;
}

void manager::set_phNUM(){
    cout<<"Enter Manager's Phone number: ";
    cin>>ph_num;
}

void manager::set_address(){
    cout<<"Enter Manager's Address: ";
    cin>>address;
}

void manager::set_salary(){
    cout << "Enter salary: ";
    cin >> salary;
}

string manager ::get_ID(){
    return staff_id;
}

string manager::get_name(){
    return staff_name;
}

string manager::get_address(){
    return address;
}

double manager::get_salary(){
    return salary;
}

string manager::get_password(){
    return pass;
}

string manager::get_username(){
    return username;
}

string manager ::get_phNUM(){
    return ph_num;
}