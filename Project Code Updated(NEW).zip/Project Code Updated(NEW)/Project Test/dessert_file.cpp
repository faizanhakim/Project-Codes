#include <iostream>
#include <fstream>
#include "dessert.cpp"

using namespace std;

int main(){
    system("cls");
    dessert d1;
    d1.set_id();
    d1.set_item_name();
    d1.set_price();

    ofstream file;
    file.open("dessert.dat",ios::out | ios::binary);

    file.write((char*)&d1,sizeof(d1));

    file.close(); 

    
}