#include<iostream>
#include<fstream>
#include <ctime>
#include <Windows.h>
#include "order.cpp"
using namespace std;

vector<food>fd;
vector<beverages>bev;
vector<dessert>dess;
vector<waiter>wait;
vector<table>tabs;
vector<order>od;

void get_time(){
    time_t now = time(0);
   
   // convert now to string form
   char* dt = ctime(&now);

   cout << dt << endl;
}

string return_time(){
    time_t now = time(0);
   
   // convert now to string form
   char* dt = ctime(&now);

   return dt;
}


void download_food(){

    ifstream file_read("food.dat", ios::in | ios::binary);

    food obj;

    while(file_read.read((char*)&obj, sizeof(obj))){
        fd.push_back(obj);
    }

    file_read.close();

    cout<<"FOOD DATA DOWNLOADED"<<endl;
    Sleep(1000);
}

void download_dessert(){

    ifstream file_read("dessert.dat", ios::in | ios::binary);

    dessert obj;

    while(file_read.read((char*)&obj, sizeof(obj))){
        dess.push_back(obj);
    }

    file_read.close();

    cout<<"DESSERT DATA DOWNLOADED"<<endl;
    Sleep(1000);
}
void download_beverages(){
    ifstream file_read("beverages.dat", ios::in | ios::binary);

    beverages obj;

    while(file_read.read((char*)&obj, sizeof(obj))){
        bev.push_back(obj);
    }

    file_read.close();

    cout<<"BEVERAGES DATA DOWNLOADED"<<endl;
    Sleep(1000);
}

void download_table(){
    
    ifstream file_read("table.dat",ios::in | ios::binary);

    table obj;
    
    while(file_read.read((char*)&obj, sizeof(obj))){
        tabs.push_back(obj);
    }

    file_read.close();

    cout<<"TABLE DATA DOWNLOADED"<<endl;
    Sleep(1000);
}

void download_waiter(){
    ifstream file_read("waiter.dat",ios::in | ios::binary);

    waiter obj;
    while(file_read.read((char*)&obj, sizeof(obj))){
        wait.push_back(obj);
    }

    file_read.close();

    cout<<"WAITER DATA DOWNLOADED"<<endl;
    Sleep(1000);


}

void printMainMenu(){
    cout << "0. Enter Table Booking" << endl;
    cout << "1. Display Menu" << endl;
    cout << "2. Take Order" <<endl;  
    cout << "3. View all Orders"<<endl;
    cout << "4. End Day" <<endl;
    cout << "5. Print Bill" << endl;
}

void printManagerMenu(){
    cout << "1. Manage Menu" << endl;
    cout << "2. Manage Staff" << endl;
    cout << "3. Report" << endl;
    cout << "4. Shut Down System" << endl; 
}

//PRINT ALL TABLES AND STATUS
void printTableMenu(){
    for(int i=0;i<tabs.size();i++){
        tabs[i].display();
        cout<<endl;
    }    
}

void set_manager(manager man){
    man.set_userName();
    man.set_password();
}

void printWaiterMenu(){
    cout<<"ALL WAITERS:"<<endl;
    for(int i=0;i<wait.size();i++){
        cout << i+1 << ". ";
        wait[i].display();
        cout<<endl;
    }
}

//PRINT RESTAURANT ITEMS
void printMenu(class Menu m){
    cout<<"FOOD ITEMS:\n"<<endl;
    m.display_food();

    cout<<"BEVERAGE ITEMS:\n"<<endl;
    m.display_beverage();

    cout<<"DESSERT ITEMS:\n"<<endl;
    m.display_dessert();

}

void printStaff(){cout<<"Print All Staff with designation"<<endl;}

void CheckReturn(){
    while(true){
        cout<<"Wish to go back(Y.YES N.NO): ";
        char flag;
        cin>>flag;
        if(flag=='Y'){
            system("CLS");
            break;
        }
        else{continue;}
    } 

}


int main(){
system("CLS");

download_food();
download_beverages();
download_dessert();
download_table();
download_waiter();

class Menu restaurant_menu;

restaurant_menu.assign_food(fd);
restaurant_menu.assign_beverages(bev);
restaurant_menu.assign_dessert(dess);


cout<<"MENU CREATED"<<endl;
Sleep(1000);

manager manage;
set_manager(manage);

system("CLS");

cout<<"ALL AVAILABLE TABLES: "<<endl << endl;
printTableMenu();
cout<<endl;
printWaiterMenu();

cout<<"PLease Assign Waiters to tables"<<endl;

for(int i=0;i<tabs.size();i++){
    cout<<"FOR TABLE "<<tabs[i].get_tableID()<<": "<<endl; 
    tabs[i].assign_waiter(wait);
    cout<<endl;
}

cout << "\t\t\t\t\t Begin Day(Y.YES N.NO): ";
char manage_flag;
cin>>manage_flag;
system("CLS");


while(manage_flag=='Y'){
    printMainMenu();

    int cus_choice;
    cout<<"Enter Selection: ";  
    cin>>cus_choice;

    switch(cus_choice){

        case 0:{
            system("CLS");

            printTableMenu();
            
            cout << "Select Table by Table's ID: ";
            string temp_id;
            cin >> temp_id;
            bool found = false;

            for(int i=0;i<tabs.size();i++){
                if (temp_id == tabs[i].get_tableID() && tabs[i].get_available()==true){
                        tabs[i].set_available(false);
                        cout << "Table Booked Successfully!" << endl;
                        found = true;
                        tabs[i].set_customer();
                        break;
                    }
                    else{
                        found = false;
                    }
            }
            
            if (found == false){
                cout << "Table unavailable!" << endl;
            }
            Sleep(1000);
            system("CLS");
            printTableMenu();

            CheckReturn();
            break;
        }

        case 1:{
            system("CLS");
            printMenu(restaurant_menu);
            CheckReturn();
            break;
        }

       
        case 2:{
            system("CLS");
            order temp_od;
            printTableMenu();
            bool book = temp_od.set_table(tabs);
            if (book == true ){

            system("CLS");
            printMenu(restaurant_menu);

            cout<<"Enter number of items: ";
            int item_num;
            cin>>item_num;

            
            temp_od.set_order(restaurant_menu,item_num);
            od.push_back(temp_od);
            cout<<"YOUR ORDER HAS BEEN TAKEN\nPLEASE BE PATIENT"<<endl;
            CheckReturn();
            break;
            }
            else{
                Sleep(1000);
                system("CLS");
                CheckReturn();
                break;
            }
        }

        case 5:{
            //Print all bills using objects;
            system("CLS");
            get_time();
            cout << endl;
            for(int i=0;i<od.size();i++){
                od[i].bill();
                cout << i+1 << ". ";
                od[i].display_bill();
                cout << endl;
            }
            CheckReturn();
            break;
        }

        case 3:{
            system("CLS");
            cout<<"All Orders Made: \n"<<endl;
            for(int i=0; i<od.size();i++){
                od[i].display();    
                cout<<"\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n";
            }

            CheckReturn();
            break;
        }

    }//switch end

    if(cus_choice == 4)
    break;

}


cout<<"\nAll dealings closed!\n"<<endl;
cout << "Do you want to make changes?(Y/N)"<< endl;
char c;
string un;
string p;
cin >> c;
if (c == 'Y'){
    cout << "Enter user name: ";
    cin >> un;

    cout << endl;

    cout << "Enter password: ";
    cin >> p;

//if(un.compare(manage.get_username()) == 0 || p.compare(manage.get_password()) == 0){
    system("CLS");
    while(true){
        cout << "Manager Menu:" << endl;
        cout << endl;
 
        printManagerMenu();

        int man_choice;
        cout<<"Enter Selection: ";  
        cin>>man_choice;

        switch(man_choice){
            case 1:{
                system("CLS");
                cout<<"0.Add Item\n1.Remove Item" << endl;
                cout << "Enter Selection: ";
                int item_choice;
                cin>>item_choice;
                switch (item_choice){
                    case 0:{
                        system("CLS");
                        cout << "\t\t\t\t Adding Item!" << endl;
                        cout << "Enter item type (F/D/B): ";
                        char t;
                        cin >> t;
                    
                        if(t =='F'){
                            food temp_f;
                            temp_f.set_foodID();
                            temp_f.set_item_name();
                            temp_f.set_price();

                            fd.push_back(temp_f);

                            for(int i=0;i<fd.size();i++){
                                fd[i].display();
                                cout << endl;
                            }
                            
                            ofstream file;
                            file.open("food.dat",ios::out | ios::binary);
                            
                            for(int i=0;i<fd.size();i++){
                                file.write((char*)&fd[i],sizeof(fd[i]));
                            }
                            
                            file.close();
                        }

                        else if(t == 'D'){
                            dessert temp_d1;
                            temp_d1.set_id();
                            temp_d1.set_item_name();
                            temp_d1.set_price();

                            dess.push_back(temp_d1);
                            for(int i=0;i<dess.size();i++){
                                dess[i].display();
                                cout << endl;
                            }

                            ofstream file;
                            file.open("dessert.dat",ios::out | ios::binary);
                            
                            for(int i=0; i<dess.size();i++){
                                file.write((char*)&dess[i],sizeof(dess[i]));
                            }

                            file.close(); 
                    
                        }

                        else if(t == 'B'){
                            beverages temp_b;
                            temp_b.set_beverageID();
                            temp_b.set_item_name();
                            temp_b.set_price();

                            bev.push_back(temp_b);
                        
                            for(int i=0;i<bev.size();i++){
                                bev[i].display();
                                cout << endl;
                            }

                            ofstream file;
                            file.open("beverages.dat",ios::out | ios::binary);

                            for(int i=0;i<bev.size();i++){
                                file.write((char*)&bev[i],sizeof(bev[i]));
                            }

                            file.close();
 
                        }
                        char key;
                        cout << "Enter Q to continue:";
                        cin >> key;
                        while (key != 'Q'){
                            cout << "Enter Q to contine:";
                            cin >> key;
                        }
                        system("CLS");
                    //printManagerMenu();                      
                        break;
                    }
                    case 1:{
                        cout << "Enter item type to erase(F/D/B): ";
                        char tp;
                        cin >> tp;

                        if(tp == 'F'){
                            for (int i=0;i<fd.size();i++){
                                cout << i+1 << ". ";
                                fd[i].display();
                                cout << endl;
                            }
                            cout << "Enter index you wnat to erase: ";
                            int n;
                            cin >> n;

                            fd.erase(fd.begin() + (n-1),fd.begin() + n);
                            cout << endl << "Item erased Successfully!" << endl;
                            system("CLS");
                            cout << "\t\t\t\tUpdated Food List" << endl << endl;
                            for(int i=0;i<fd.size();i++){
                                cout << i+1 << ". ";
                                fd[i].display();
                                cout << endl;
                            }

                            ofstream file;
                            file.open("food.dat",ios::out | ios::binary);
                            
                            for(int i=0;i<fd.size();i++){
                                file.write((char*)&fd[i],sizeof(fd[i]));
                            }
                            
                            file.close();
                        }
                   
                        else if(tp == 'B'){
                            for (int i=0;i<bev.size();i++){
                                cout << i+1 << ". ";
                                bev[i].display();
                                cout << endl;
                            }
                            cout << "Enter index you wnat to erase: ";
                            int n;
                            cin >> n;

                            bev.erase(bev.begin() + (n-1),bev.begin() + n);
                            cout << endl << "Item erased Successfully!" << endl;
                            cout << "\t\t\t\tUpdated Food List" << endl << endl;
                            
                            for(int i=0;i<bev.size();i++){
                                cout << i+1 << ". ";
                                bev[i].display();
                                cout << endl;
                            }

                            ofstream file;
                            file.open("beverages.dat",ios::out | ios::binary);

                            for(int i=0;i<bev.size();i++){
                                file.write((char*)&bev[i],sizeof(bev[i]));
                            }

                            file.close();
                        }                   

                        else if(tp == 'D'){
                            for (int i=0;i<dess.size();i++){
                                cout << i+1 << ". ";
                                dess[i].display();
                                cout << endl;
                            }
                            cout << "Enter index you wnat to erase: ";
                            int n;
                            cin >> n;

                            dess.erase(dess.begin() + (n-1),dess.begin() + n);
                            cout << endl << "Item erased Successfully!" << endl;
                            cout << "\t\t\t\tUpdated Food List" << endl << endl;
                            
                            for(int i=0;i<dess.size();i++){
                                cout << i+1 << ". ";
                                dess[i].display();
                                cout << endl;
                            }

                            ofstream file;
                            file.open("dessert.dat",ios::out | ios::binary);
                            
                            for(int i=0; i<dess.size();i++){
                                file.write((char*)&dess[i],sizeof(dess[i]));
                            }

                            file.close();
                        }

                        char key;
                        cout << "Enter Q to continue:";
                        cin >> key;
                        while (key != 'Q'){
                            cout << "Enter Q to contine:";
                            cin >> key;
                        }
                        system("CLS");
                        break;
                    }

                    default:
                        break;
                    }
                break;
                
            }
            case 2:{
                system("CLS");
                
                cout<<"0.Add Waiter\n1.Remove Waiter" << endl;
                cout << "Enter selection: ";
                int staff_choice;
                cin>>staff_choice;
                switch(staff_choice){
                    case 0:{
                        system("CLS");
                        cout << "Enter Waiter details!" << endl << endl;
                        waiter temp_w;
                        temp_w.set_ID();
                        temp_w.set_name();
                        temp_w.set_phNUM();
                        temp_w.set_address();
                        temp_w.set_salary();

                        wait.push_back(temp_w);
                        system("CLS");
                        cout << endl << "\t\t\t\tUpdated waiter list!" << endl;

                        printWaiterMenu();

                        ofstream file("waiter.dat",ios::out | ios::binary);

                        for(int i=0;i<wait.size();i++){
                            file.write((char*)&wait[i],sizeof(wait[i]));
                        }
                        
                        file.close();


                        char key;
                        cout << "Enter Q to continue:";
                        cin >> key;
                        while (key != 'Q'){
                            cout << "Enter Q to contine:";
                            cin >> key;
                        }
                        system("CLS");
                        break;                        
                    }

                    case 1:{
                        system("CLS");
                        printWaiterMenu();
                        cout << "Enter index you wnat to erase: ";
                        int n;
                        cin >> n;

                        wait.erase(wait.begin() + (n-1),wait.begin() + n);
                        cout << endl << "Item erased Successfully!" << endl;
                        cout << "\t\t\t\tUpdated Food List" << endl << endl;
                            
                        for(int i=0;i<wait.size();i++){
                            cout << i+1 << ". ";
                            wait[i].display();
                            cout << endl;
                        }

                        ofstream file("waiter.dat",ios::out | ios::binary);

                        for(int i=0;i<wait.size();i++){
                            file.write((char*)&wait[i],sizeof(wait[i]));
                        }
                        
                        file.close();
                        
                        char key;
                        cout << "Enter Q to continue:";
                        cin >> key;
                        while (key != 'Q'){
                            cout << "Enter Q to contine:";
                            cin >> key;
                        }
                        system("CLS");
                        break;                         
                    }
                }
                //CheckReturn();
                break;
                //Make changes in file
            }
        }
    
        if(man_choice == 4){
            break;
        }

    }
    

}
cout << "\t\t\t\t\t\t\t\tALL CHANGES HAVE BEEN MADE!" << endl;
Sleep(1000);
system("CLS");
cout << "\t\t\t\t\t\t\t\t\tSYSTEM SHUTTING DOWN........." << endl;
Sleep(2000);
}//main end
