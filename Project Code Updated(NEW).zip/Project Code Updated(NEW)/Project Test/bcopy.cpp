#include <iostream>
#include <fstream>
#include "beverage.cpp"


using namespace std;

int main(){
    system("cls");


    ifstream file_read("beverages.dat", ios::in | ios::binary);

    beverages obj;
    file_read.read((char*)&obj, sizeof(obj));
    
    while(file_read){
        obj.display();
        file_read.read((char*)&obj, sizeof(obj));
    }

    file_read.close();
    //obj.display();
    cout << "Program ended! " << endl;
  
}