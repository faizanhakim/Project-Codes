#include <iostream>
#include "dessert.h"

using namespace std;

void dessert ::set_id(){
    cout << "Enter dessert id: ";
    cin >> dessert_id;
}

string dessert::get_dessertID(){
    return dessert_id;
}

void dessert::set_item_name(){
    cout << "Enter item name:";
    cin >> dessert_name;  
}
void dessert::set_price(){
    cout << "Enter item price: ";
    cin >> price;
}   

string dessert::get_item_name(){
    return dessert_name;
}

double dessert::get_price(){
    return price;
}

void dessert::set_quantity(){
    cout << "Enter quantity: ";
    cin >> quantity;
}

int dessert ::get_quantity(){
    return quantity;
}

void dessert::display(){
    cout << "Dessert ID: " << dessert_id << endl;
    cout << "Dessert Name: " << dessert_name << endl;
    cout << "Dessert Price: " << price << endl;
}
