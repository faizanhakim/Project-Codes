#include<iostream>
#include "food.h"
using namespace std;


void printMainMenu(){
    cout<<"0. Enter Booking\n1. Select Menu\n2. Manage Staff\n3. Manage Menu\n4. Report\n6. End Day"<<endl;
}

void printTableMenu(){cout<<"ALL AVALIABLE TABLES: "<<endl;}
void printMenu(){cout<<"ALL ITEMS ARE PRINTED"<<endl;}
void printStaff(){cout<<"Print All Staff with designation"<<endl;}

void CheckReturn(){
    while(true){
        cout<<"Wish to go back(Y.YES N.NO): ";
        char flag;
        cin>>flag;
        if(flag=='Y'){
            system("CLS");
            break;
        }
        else{continue;}
    } 

}


int main(){
system("CLS");

food f1("F0","Pizza",100);
food f2("F1","Pasta",120);

cout<<"Begin Day(Y.YES N.NO): ";
char manage_flag;
cin>>manage_flag;

while(manage_flag=='Y'){
    printMainMenu();

    int cus_choice;
    cout<<"Enter Selection: ";  
    cin>>cus_choice;

    switch(cus_choice){

        case 0:{
            printTableMenu();
            cout<<"Select Table by Table's ID: ";
            string temp_id;
            cin>>temp_id;

            //Check and book Table;
            CheckReturn();
            break;
        }

        case 1:{
            printMenu();
            cout<<"Enter Number of Items: ";
            int item_num;
            cin>>item_num;

            for(int i=0;i<item_num;i++){
                cout<<"Enter dish ID: ";
                //Add all the items, based on ID, into the appropriate object using shallow or deep copy;
            }
            CheckReturn();
            break;
        }


        case 2:{
            printStaff();
            cout<<"0.Add Staff\n1.Remove Staff";
            int staff_choice;
            cin>>staff_choice;
            //Work with staff member funtions to do this
            CheckReturn();
            break;
            //Make changes in file
        }


        case 3:{
            printMenu();
            cout<<"0.Add Item\n1.Remove Item\n2.Change Item Price";
            int item_choice;
            cin>>item_choice;
            CheckReturn();
            break;
            //Made changes in file
        }

        case 4:{
            //Print all bills using objects;
            CheckReturn();
            break;
        }

    }//switch end

    if(cus_choice == 6)
    break;

}


cout<<"\nTHE DAY HAS ENDED\n"<<endl;
}//main end
