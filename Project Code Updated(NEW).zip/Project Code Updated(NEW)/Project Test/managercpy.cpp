#include<iostream>
#include<fstream>
#include"manager.cpp"

using namespace std;

int main(){

    manager temp_man;

    ifstream file;
    file.open("Manager.dat",ios::binary);
    if(!file){
        cout<<"Error Loading FIle";
        exit(1);
    }
    file.read((char*)&temp_man,sizeof(temp_man));

    cout<<temp_man.get_username()<<endl;
    cout<<temp_man.get_password()<<endl;
    cout<<temp_man.get_name()<<endl;

}